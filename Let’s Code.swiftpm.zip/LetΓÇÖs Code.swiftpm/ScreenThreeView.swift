import SwiftUI

struct ScreenThreeView: View {
    @Environment(\.colorScheme) var colorScheme: ColorScheme
    @Environment(\.horizontalSizeClass) var horizontalSizeClass
    @Environment(\.verticalSizeClass) var verticalSizeClass
    @State private var framesLight: [String] = ["InitialLight"]
    @State private var framesDark: [String] = ["InitialDark"]
    @State private var currentImageIndex = 0
    @State private var execute: Bool = false
    @State private var itemsDark: [String] = []
    @State private var itemsLight: [String] = []
    @State private var scrollToBottom: Bool = false
    @State private var timer: Timer?
    @State private var isTimerStopped = false
    @State private var scrollToIndex: Int? = nil
    @State private var isChecked: Bool = false
    @State private var isCorrect: Bool = false
    
    @State var maze: Maze = Maze()
    
    var body: some View {
        GeometryReader { reader in
            ZStack {
                colorScheme == .dark ? Color(red: 14/255, green: 34/255, blue: 47/255) : Color(red: 218/255, green: 234/255, blue: 238/255)
                
                HStack (alignment: .center) {
                    Spacer()
                    
                    VStack {
                        HStack {
                            Spacer()
                            if colorScheme == .dark {
                                Image(framesDark[currentImageIndex])
                                    .resizable()
                                    .scaledToFit()
                                    .frame(width: reader.size.width/1.8)
                                    .transition(.slide)
                            } else {
                                Image(framesLight[currentImageIndex])
                                    .resizable()
                                    .scaledToFit()
                                    .frame(width: reader.size.width/1.8)
                                    .transition(.slide)
                            }
                            Spacer()
                        }
                        
                        Spacer()
                            .frame(maxHeight: 100)
                        
                        VStack {
                            HStack {
                                if colorScheme == .dark {
                                    Image("ScreenThreeOptionsDark")
                                        .resizable()
                                        .scaledToFit()
                                        .frame(height: reader.size.height/30)
                                } else {
                                    Image("ScreenThreeOptionsLight")
                                        .resizable()
                                        .scaledToFit()
                                        .frame(height: reader.size.height/30)
                                }
                                Spacer()
                            }
                            
                            Spacer()
                                .frame(maxHeight: 20)
                            
                            HStack {
                                Button(action: {
                                    let newItem = "MoveForward"
                                    addItem(newItem)
                                    scrollToBottom = true
                                    maze.appendMove()
                                    let newFrame: [String] = maze.getFrame()
                                    if newFrame != [""] {
                                        framesDark.append(newFrame[0])
                                        framesLight.append(newFrame[1])
                                    }
                                }, label: {
                                    if colorScheme == .dark {
                                        Image("MoveForwardDark2")
                                            .resizable()
                                            .scaledToFit()
                                            .frame(height: 42)
                                    } else {
                                        Image("MoveForwardLight2")
                                            .resizable()
                                            .scaledToFit()
                                            .frame(height: 42)
                                    }
                                })
                                
                                Spacer()
                                
                                Button(action: {
                                    let newItem = "TurnLeft"
                                    addItem(newItem)
                                    scrollToBottom = true
                                    maze.turnLeft()
                                }, label: {
                                    if colorScheme == .dark {
                                        Image("TurnLeftDark2")
                                            .resizable()
                                            .scaledToFit()
                                            .frame(height: 42)
                                    } else {
                                        Image("TurnLeftLight2")
                                            .resizable()
                                            .scaledToFit()
                                            .frame(height: 42)
                                    }
                                })
                                
                                Spacer()
                                
                                Button(action: {
                                    let newItem = "TurnRight"
                                    addItem(newItem)
                                    scrollToBottom = true
                                    maze.turnRigth()
                                }, label: {
                                    if colorScheme == .dark {
                                        Image("TurnRightDark2")
                                            .resizable()
                                            .scaledToFit()
                                            .frame(height: 42)
                                    } else {
                                        Image("TurnRightLight2")
                                            .resizable()
                                            .scaledToFit()
                                            .frame(height: 42)
                                    }
                                })
                                Spacer()
                            }
                            .frame(height: 80)
                        }
                    }
                    .padding(.leading, 50)
                    
                    Spacer()
                    
                    HStack {
                        Spacer()
                        VStack {
                            ZStack {
                                if colorScheme == .dark {
                                    Image("ScreenThreeInstructionsDark")
                                        .resizable()
                                        .scaledToFit()
                                        .frame(height: reader.size.height*0.65)
                                } else {
                                    Image("ScreenThreeInstructionsLight")
                                        .resizable()
                                        .scaledToFit()
                                        .frame(height: reader.size.height*0.65)
                                }
                                
                                if colorScheme == .dark {
                                    
                                    ScrollView {
                                        ScrollViewReader { scrollView in
                                            VStack {
                                                ForEach(itemsDark.indices, id: \.self) { index in
                                                    Image(itemsDark[index])
                                                        .resizable()
                                                        .aspectRatio(contentMode: .fit)
                                                        .frame(height: 65)
                                                        .padding(.vertical, -8)
                                                        .id(index)
                                                }
                                                .background(
                                                    GeometryReader { geometry in
                                                        Color.clear
                                                            .onAppear {
                                                                if let index = scrollToIndex {
                                                                    DispatchQueue.main.async {
                                                                        scrollView.scrollTo(index, anchor: .bottom)
                                                                        scrollToIndex = nil
                                                                    }
                                                                }
                                                            }
                                                    }
                                                )
                                            }
                                        }
                                    }
                                    .padding(.bottom, 20)
                                    .padding(.top, 75)
                                    .frame(height: reader.size.height*0.65)
                                    .padding()
                                    
                                } else {
                                    ScrollView {
                                        ScrollViewReader { scrollView in
                                            VStack {
                                                ForEach(itemsLight.indices, id: \.self) { index in
                                                    Image(itemsLight[index])
                                                        .resizable()
                                                        .aspectRatio(contentMode: .fit)
                                                        .frame(height: 65)
                                                        .padding(.vertical, -8)
                                                        .id(index)
                                                }
                                                .background(
                                                    GeometryReader { geometry in
                                                        Color.clear
                                                            .onAppear {
                                                                if let index = scrollToIndex {
                                                                    DispatchQueue.main.async {
                                                                        scrollView.scrollTo(index, anchor: .bottom)
                                                                        scrollToIndex = nil
                                                                    }
                                                                }
                                                            }
                                                    }
                                                )
                                            }
                                        }
                                    }
                                    .padding(.bottom, 20)
                                    .padding(.top, 75)
                                    .frame(height: reader.size.height*0.65)
                                    .padding()
                                }
                                
                                if colorScheme == .dark {
                                    if isChecked {
                                        if isCorrect {
                                            Image("ScreenThreeAcceptDark")
                                                .resizable()
                                                .scaledToFit()
                                                .frame(height: reader.size.height*0.65)
                                        } else {
                                            Image("ScreenThreeDenyDark")
                                                .resizable()
                                                .scaledToFit()
                                                .frame(height: reader.size.height*0.65)
                                        }
                                    }
                                } else {
                                    if isChecked {
                                        if isCorrect {
                                            Image("ScreenThreeAcceptLight")
                                                .resizable()
                                                .scaledToFit()
                                                .frame(height: reader.size.height*0.65)
                                        } else {
                                            Image("ScreenThreeDenyLight")
                                                .resizable()
                                                .scaledToFit()
                                                .frame(height: reader.size.height*0.65)
                                        }
                                    }
                                }
                            }
                            
                            HStack {
                                Button {
                                    removeAllItems()
                                    maze.delete()
                                    currentImageIndex = 0
                                } label: {
                                    if colorScheme == .dark {
                                        Image("DeleteDark")
                                            .resizable()
                                            .scaledToFit()
                                            .frame(height: 50)
                                    } else {
                                        Image("DeleteLight")
                                            .resizable()
                                            .scaledToFit()
                                            .frame(height: 50)
                                    }
                                }
                                
                                Button {
                                    self.timer = Timer.scheduledTimer(withTimeInterval: 0.2, repeats: true) { timer in
                                        withAnimation {
                                            currentImageIndex = (currentImageIndex + 1) % framesDark.count
                                            
                                            if currentImageIndex == framesDark.count - 1 {
                                                timer.invalidate()
                                                
                                                let check = maze.check()
                                                isChecked = true
                                                
                                                if check {
                                                    isCorrect = true
                                                    DispatchQueue.main.asyncAfter(deadline: .now() + 1.5) {
                                                        isTimerStopped = true
                                                    }
                                                } else {
                                                    isCorrect = false
                                                }
                                                
                                                DispatchQueue.main.asyncAfter(deadline: .now() + 1.5) {
                                                    isChecked = false
                                                }
                                            }
                                        }
                                    }
                                    
                                } label: {
                                    if colorScheme == .dark {
                                        Image("ConfirmDark")
                                            .resizable()
                                            .scaledToFit()
                                            .frame(height: 50)
                                    } else {
                                        Image("ConfirmLight")
                                            .resizable()
                                            .scaledToFit()
                                            .frame(height: 50)
                                    }
                                }
                            }
                        }
                        Spacer()
                    }
                    Spacer()
                }
            }
        }
        .background(
            NavigationLink(destination: ScreenFourView(), isActive: $isTimerStopped) {
                EmptyView()
            }
        )
        .navigationBarTitle(Text("Let's Code!")).background(colorScheme == .dark ? Color(red: 14/255, green: 34/255, blue: 47/255) : Color(red: 218/255, green: 234/255, blue: 238/255))
        
    }
    
    func addItem(_ item: String) {
        itemsDark.append("\(item)Dark")
        itemsLight.append("\(item)Light")
        scrollToIndex = self.itemsDark.count - 1
    }
    
    func removeAllItems() {
        itemsDark.removeAll()
        itemsLight.removeAll()
        framesDark.removeAll()
        framesLight.removeAll()
        framesDark.append("InitialDark")
        framesLight.append("InitialLight")
    }
    
}
