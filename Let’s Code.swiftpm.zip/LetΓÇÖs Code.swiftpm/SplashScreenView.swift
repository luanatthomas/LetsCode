import SwiftUI

struct SplashScreenView : View{
    @Environment(\.colorScheme) var colorScheme: ColorScheme

    @State var isActive: Bool = false
    @State var scale: Double = 1
    
    var body : some View {
        if self.isActive {
            ScreenOneView()
        } else {
            ZStack {
                
                colorScheme == .dark ? Color(red: 14/255, green: 34/255, blue: 47/255) : Color(red: 218/255, green: 234/255, blue: 238/255)      
                
                GeometryReader { reader in
                    HStack {
                        Spacer() 
                        VStack {
                            Spacer()
                            if colorScheme == .dark {
                                Image("SplashScreenImageDark")
                                    .resizable()
                                    .aspectRatio(contentMode: .fit)
                                    .frame(width: reader.size.width/3)
                                    .scaleEffect(scale)
                                    .onAppear{
                                        withAnimation(.easeIn(duration: 1.5)) {
                                            self.scale = 1.5
                                        }
                                    }
                            } else {
                                Image("SplashScreenImageLight")
                                    .resizable()
                                    .aspectRatio(contentMode: .fit)
                                    .frame(width: reader.size.width/3)
                                    .scaleEffect(scale)
                                    .onAppear{
                                        withAnimation(.easeIn(duration: 1.5)) {
                                            self.scale = 1.5
                                        }
                                    }
                            }
                            Spacer()
                        }
                        Spacer()
                    } 
                }
            }
            .navigationBarBackButtonHidden()
            .ignoresSafeArea()
            .onAppear {
                DispatchQueue.main.asyncAfter(deadline: .now() + 3) {
                    withAnimation {
                        self.isActive = true
                    }
                }
                
            }    
        }
        
        
    }
}
