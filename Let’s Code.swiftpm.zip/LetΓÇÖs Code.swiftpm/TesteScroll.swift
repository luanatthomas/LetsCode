//
//  TesteScroll.swift
//  LetsCode
//
//  Created by Luana Tais Thomas on 23/02/24.
//

import Foundation
import SwiftUI

struct TesteScroll: View {
    @State private var items: [String] = ["ItemA", "ItemB", "ItemA", "ItemC"]
    @State private var scrollToBottom: Bool = false
    
    var body: some View {
        VStack {
            ScrollView {
                ScrollViewReader { scrollView in
                    VStack {
                        ForEach(items, id: \.self) { item in
                            Text(item)
                                .padding()
                                .id(item)
                        }
                        .background(
                            GeometryReader { geometry in
                                Color.clear
                                    .onAppear {
                                        if scrollToBottom {
                                            DispatchQueue.main.async {
                                                scrollView.scrollTo(items.last, anchor: .bottom)
                                                scrollToBottom = false
                                            }
                                        }
                                    }
                            }
                        )
                    }
                }
            }
            .padding(.bottom, 100) // Adiciona um espaço extra na parte inferior para garantir que a rolagem funcione corretamente
            
            Button("Adicionar Item") {
                let newItem = "Novo Item \(self.items.count + 1)"
                self.items.append(newItem)
                scrollToBottom = true
            }
            .padding()
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
    }
}
