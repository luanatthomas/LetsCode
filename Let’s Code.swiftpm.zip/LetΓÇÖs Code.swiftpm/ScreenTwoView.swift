import SwiftUI

struct ScreenTwoView : View {
    @Environment(\.colorScheme) var colorScheme: ColorScheme

    var body : some View {
        GeometryReader { reader in 
            ZStack {
                colorScheme == .dark ? Color(red: 14/255, green: 34/255, blue: 47/255) : Color(red: 218/255, green: 234/255, blue: 238/255)      
                
                VStack {
                    HStack {
                        Spacer()
                        if colorScheme == .dark {
                            Image("ScreenTwoImageDark")
                                .resizable()
                                .scaledToFit()
                                .frame(width: reader.size.width/5)
                        } else {
                            Image("ScreenTwoImageLight")
                                .resizable()
                                .scaledToFit()
                                .frame(width: reader.size.width/5)
                        }
                    }
                    Spacer()
                }
                .padding(.top, reader.size.height/5)
                .padding(.trailing, reader.size.width/15)
                
                VStack {
                    HStack {
                        if colorScheme == .dark {
                            Image("ScreenTwoTextDark")
                                .resizable()
                                .scaledToFit()
                                .frame(width: reader.size.width/1.7)
                        } else {
                            Image("ScreenTwoTextLight")
                                .resizable()
                                .scaledToFit()
                                .frame(width: reader.size.width/1.7)
                        }
                        Spacer()
                    }
                    Spacer()
                        .frame(maxHeight: 120)
                    
                    HStack {
                        if colorScheme == .dark {
                            Image("ScreenTwoInstructionsDark")
                                .resizable()
                                .scaledToFit()
                                .frame(width: reader.size.width/2)
                        } else {
                            Image("ScreenTwoInstructionsLight")
                                .resizable()
                                .scaledToFit()
                                .frame(width: reader.size.width/2)
                        }
                        Spacer()
                    }
                    Spacer()
                    
                }
                .padding(.leading, reader.size.width/9)
                .padding(.top, reader.size.height/6)
                
                VStack {
                    
                }
                .padding(.leading, reader.size.width/9)
                
                VStack {
                    Spacer()
                    HStack {
                        Spacer()
                        NavigationLink { 
                            ScreenThreeView()
                        } label: { 
                            if colorScheme == .dark {
                                Image("ScreenTwoButtonDark")
                                    .resizable()
                                    .scaledToFit()
                                    .frame(height: reader.size.height/20)
                            } else {
                                Image("ScreenTwoButtonLight")
                                    .resizable()
                                    .scaledToFit()
                                    .frame(height: reader.size.height/20)
                            }
                        }
                    }
                }
                .padding(.bottom, reader.size.height/18)
                .padding(.trailing, reader.size.width/20)
                
            }
        }
        .navigationBarTitle(Text("Let's Code!")).background(colorScheme == .dark ? Color(red: 14/255, green: 34/255, blue: 47/255) : Color(red: 218/255, green: 234/255, blue: 238/255))        
    }
}
