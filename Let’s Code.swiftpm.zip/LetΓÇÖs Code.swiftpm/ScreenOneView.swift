import SwiftUI

struct ScreenOneView : View {
    @Environment(\.colorScheme) var colorScheme: ColorScheme
    
    var body : some View {
        NavigationStack {
            GeometryReader { reader in
                ZStack {
                    colorScheme == .dark ? Color(red: 14/255, green: 34/255, blue: 47/255) : Color(red: 218/255, green: 234/255, blue: 238/255)      
                    
                    HStack {
                        Spacer()
                        VStack {
                            if colorScheme == .dark {
                                Image("ScreenOneTextDark")
                                    .resizable()
                                    .scaledToFit()
                                    .frame(width: reader.size.width - reader.size.width/2.2)
                            } else {
                                Image("ScreenOneTextLight")
                                    .resizable()
                                    .scaledToFit()
                                    .frame(width: reader.size.width - reader.size.width/2.2)
                            }
                            Spacer()
                        }
                        .padding(.top, reader.size.height/5)

                        Spacer()
                        
                        VStack {
                            if colorScheme == .dark {
                                Image("ScreenOneImageDark")
                                    .resizable()
                                    .scaledToFit()
                                    .frame(width: reader.size.width/4)
                            } else {
                                Image("ScreenOneImageLight")
                                    .resizable()
                                    .scaledToFit()
                                    .frame(width: reader.size.width/4)
                            }
                            Spacer ()
                        }
                        .padding(.top, reader.size.height/5)
                        Spacer()
                    }                                            
                    
                    VStack {
                        Spacer()
                        HStack {
                            Spacer()
                            NavigationLink { 
                                ScreenTwoView()
                            } label: { 
                                if colorScheme == .dark {
                                    Image("ScreenOneButtonDark")
                                        .resizable()
                                        .scaledToFit()
                                        .frame(height: reader.size.height/20)
                                } else {
                                    Image("ScreenOneButtonLight")
                                        .resizable()
                                        .scaledToFit()
                                        .frame(height: reader.size.height/20)
                                }
                            }
                        }
                    }
                    .padding(.bottom, reader.size.height/18)
                    .padding(.trailing, reader.size.width/20)
                    
                }
            }
        }
        .navigationBarTitle(Text("Let's Code!")).background(colorScheme == .dark ? Color(red: 14/255, green: 34/255, blue: 47/255) : Color(red: 218/255, green: 234/255, blue: 238/255)     )
        .accentColor(colorScheme == .dark ? Color(red: 218/255, green: 234/255, blue: 238/255) : Color(red: 14/255, green: 34/255, blue: 47/255))
        .navigationBarBackButtonHidden() 
    }
}


