import SwiftUI

struct Maze {

    var guess: [String]
    var actualMove: String
    var actualPosition: Int
    var position: Int
    var isPossibleFrame = true
    
    let maze: [Int: String] = [
        10: "1101",
        11: "0001",
        12: "0101",
        13: "0011",
        14: "1101",
        15: "0011",
        21: "1010",
        22: "1101",
        23: "0100",
        24: "0101",
        25: "0010",
        31: "1100",
        32: "0111",
        33: "1101",
        34: "0101",
        35: "0100"
    ]
    
    let frames: [Int: [String]] = [
        10: ["InitialDark", "InitialLight"],
        11: ["11Dark", "11Light"],
        12: ["12Dark", "12Light"],
        13: ["13Dark", "13Light"],
        14: ["14Dark", "14Light"],
        15: ["15Dark", "15Light"],
        21: ["21Dark", "21Light"],
        22: ["22Dark", "22Light"],
        23: ["23Dark", "23Light"],
        24: ["24Dark", "24Light"],
        25: ["25Dark", "25Light"],
        31: ["31Dark", "31Light"],
        32: ["32Dark", "32Light"],
        33: ["33Dark", "33Light"],
        34: ["34Dark", "34Light"],
        35: ["35Dark", "35Light"]
    ]

    init() {
        self.guess = []
        self.actualMove = "0010"
        self.actualPosition = 10
        self.position = 10
    }
    
    mutating func appendMove() {
        self.guess.append(actualMove)
    }
    
    mutating func turnLeft() {
        if actualMove == "1000" {
            self.actualMove = "0100"
        } else if actualMove == "0100" {
            self.actualMove = "0010"
        } else if actualMove == "0010" {
            self.actualMove = "0001"
        } else if actualMove == "0001" {
            self.actualMove = "1000"
        }
    }
    
    mutating func turnRigth() {
        if actualMove == "1000" {
            self.actualMove = "0001"
        } else if actualMove == "0001" {
            self.actualMove = "0010"
        } else if actualMove == "0010" {
            self.actualMove = "0100"
        } else if actualMove == "0100" {
            self.actualMove = "1000"
        }
    }
    
    mutating func delete() {
        self.position = 10
        self.actualPosition = 10
        self.actualMove = "0010"
        self.guess = []
        self.isPossibleFrame = true
    }
    
    func isPossible(coord: Int, move: String) -> Bool {
        guard let position = maze[coord] else {
            return false
        }
        
        guard move.count == 4 else {
            return false
        }
        
        for (index, mov) in move.enumerated() {
            let codePosition = position.index(position.startIndex, offsetBy: index)
            if mov == "1" && position[codePosition] == "1" {
                return false
            }
        }
        
        return true
    }
    
    mutating func getFrame() -> [String] {
        if isPossible(coord: position, move: actualMove) && isPossibleFrame{
            if position == 35 && actualMove == "0010" {
                return ["FinalDark", "FinalLight"]
            } else {
                if actualMove == "1000" {
                    position = position - 1
                } else if actualMove == "0100" {
                    position = position + 10
                } else if actualMove == "0010" {
                    position = position + 1
                } else if actualMove == "0001" {
                    position = position - 10
                }
                
                return frames[position]!
            }
            
        } else {
            self.isPossibleFrame = false
        }
        return [""]
    }
    
    mutating func check() -> Bool {
        for g in guess {
            if isPossible(coord: actualPosition, move: g) {
                if actualPosition == 35 && g == "0010" {
                    return true
                }
                if g == "1000" {
                    actualPosition = actualPosition - 1
                } else if g == "0100" {
                    actualPosition = actualPosition + 10
                } else if g == "0010" {
                    actualPosition = actualPosition + 1
                } else if g == "0001" {
                    actualPosition = actualPosition - 10
                }
            } else {
                return false
            }
        }
        return false
    }
}
