import SwiftUI

struct ScreenFourView : View {
    @Environment(\.colorScheme) var colorScheme: ColorScheme

    var body: some View {
        GeometryReader { reader in
            ZStack {
                colorScheme == .dark ? Color(red: 14/255, green: 34/255, blue: 47/255) : Color(red: 218/255, green: 234/255, blue: 238/255)
                
                VStack {
                    HStack {
                        Spacer()
                        if colorScheme == .dark {
                            Image("ScreenFourTextDark")
                                .resizable()
                                .scaledToFit()
                                .frame(width: reader.size.width - reader.size.width/1.7)
                        } else {
                            Image("ScreenFourTextLight")
                                .resizable()
                                .scaledToFit()
                                .frame(width: reader.size.width - reader.size.width/1.7)
                        }
                        Spacer()
                    }
                    .padding(.top, reader.size.height/5)
                    
                    Spacer()
                        .frame(maxHeight: 100)
                    
                    HStack {
                        Spacer()
                        if colorScheme == .dark {
                            Image("ScreenFourImageDark")
                                .resizable()
                                .scaledToFit()
                                .frame(width: reader.size.width/5)
                        } else {
                            Image("ScreenFourImageLight")
                                .resizable()
                                .scaledToFit()
                                .frame(width: reader.size.width/5)
                        }
                        Spacer ()
                    }
                    Spacer()
                }
                
                VStack {
                    Spacer()
                    HStack {
                        Spacer()
                        NavigationLink {
                            ScreenOneView()
                        } label: {
                            if colorScheme == .dark {
                                Image("ScreenFourButtonDark")
                                    .resizable()
                                    .scaledToFit()
                                    .frame(height: reader.size.height/20)
                            } else {
                                Image("ScreenFourButtonLight")
                                    .resizable()
                                    .scaledToFit()
                                    .frame(height: reader.size.height/20)
                            }
                        }
                    }
                    .padding(.trailing, reader.size.width/20)
                }
                .padding(.bottom, reader.size.height/18)
                
            }
        }
        .navigationBarTitle(Text("Let's Code!")).background(colorScheme == .dark ? Color(red: 14/255, green: 34/255, blue: 47/255) : Color(red: 218/255, green: 234/255, blue: 238/255)     )

    }
}
